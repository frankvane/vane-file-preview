// Local module declaration for mammoth browser build
declare module "mammoth/mammoth.browser" {
  const mammoth: any;
  export default mammoth;
}
